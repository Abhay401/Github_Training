/**
 * Data transfer objects for rest mapping.
 */
package io.github.jhipster.sample.service.dto;
