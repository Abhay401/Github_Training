/**
 * Data transfer objects mappers.
 */
package io.github.jhipster.sample.service.mapper;
