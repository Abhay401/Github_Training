/**
 * Domain objects.
 */
package io.github.jhipster.sample.domain;
