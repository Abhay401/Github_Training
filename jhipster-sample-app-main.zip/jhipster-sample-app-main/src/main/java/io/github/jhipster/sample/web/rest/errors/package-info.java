/**
 * Rest layer error handling.
 */
package io.github.jhipster.sample.web.rest.errors;
