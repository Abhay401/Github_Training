/**
 * Rest layer.
 */
package io.github.jhipster.sample.web.rest;
