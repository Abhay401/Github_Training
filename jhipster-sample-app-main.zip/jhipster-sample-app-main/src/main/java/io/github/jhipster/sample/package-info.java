/**
 * Application root.
 */
package io.github.jhipster.sample;
