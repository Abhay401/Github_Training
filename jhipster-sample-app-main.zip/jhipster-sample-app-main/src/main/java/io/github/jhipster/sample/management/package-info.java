/**
 * Application management.
 */
package io.github.jhipster.sample.management;
