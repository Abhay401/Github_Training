/**
 * Service layer.
 */
package io.github.jhipster.sample.service;
