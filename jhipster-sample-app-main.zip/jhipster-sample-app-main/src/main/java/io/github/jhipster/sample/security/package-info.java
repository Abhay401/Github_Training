/**
 * Application security utilities.
 */
package io.github.jhipster.sample.security;
