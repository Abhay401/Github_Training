/**
 * Rest layer visual models.
 */
package io.github.jhipster.sample.web.rest.vm;
