/**
 * Logging aspect.
 */
package io.github.jhipster.sample.aop.logging;
