/**
 * Repository layer.
 */
package io.github.jhipster.sample.repository;
