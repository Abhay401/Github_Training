/**
 * Application configuration.
 */
package io.github.jhipster.sample.config;
